package viewOfGame;

import java.awt.Color;
import java.awt.GridBagLayout;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import model.effects.Effect;
import model.world.AntiHero;
import model.world.Champion;
import model.world.Cover;
import model.world.Hero;


public class Board extends JPanel implements ActionListener{
	
	private View jframe;
	private GamePhase game;
	private JButton [][]  buttons;
	
      public Board(GamePhase game,View jframe){
    	  this.jframe=jframe;
    	  this.game=game;
    	  this.setBounds(625, 100, 700, 700);
    	  this.setLayout(new GridLayout(5,5));
    	  buttons=new JButton[5][5];
    	  
    	  for(int i=0;i<5 ;i++){
    		  for(int j=0;j<5;j++){
    			  buttons[i][j]=new JButton();
    			  buttons[i][j].addActionListener(this);
    			  this.add(buttons[i][j]);
    			  
    		  }
    		  }
    	  
    	  fillBoard();
    	  
    	  
    	  this.revalidate();
    	  this.repaint();
    	  
    	  
      }
      
	
	
	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource() instanceof JButton){
		for(int i=0;i<5 ;i++){
  		  for(int j=0;j<5;j++){
  			  if(e.getSource()==buttons[i][j]){
  				  if(jframe.getGame().getBoard()[i][j] instanceof Champion){
  					  Champion c1=(Champion) jframe.getGame().getBoard()[i][j];
  				String s = "Name of Champion: " + c1.getName() + "\n"
  						+ "Current Healthpoints: " + c1.getCurrentHP() + "\n"
  						+ "Mana: " + c1.getMana() + "\n"+"Maximum Action Points: "+c1.getMaxActionPointsPerTurn()+"\n" + "Current Action Points: "
  						+ c1.getCurrentActionPoints() + "\n" + "Attack Damage: "
  						+ c1.getAttackDamage() + "\n" + "Attack Range: "
  						+ c1.getAttackRange() + "\n" + "Speed: " + c1.getSpeed() + "\n";
  				if(c1 instanceof Hero){
  					s+="Hero" +"\n";
  				}
  				else if(c1 instanceof AntiHero){
  					s+="AntiHero"+"\n";
  				}
  				else 
  					{s+="Villain"+"\n";}
  				if(jframe.getGame().getFirstPlayer().getLeader().getName().equals( (buttons[i][j]).getText())  ){
  					s+="Leader"+"\n";
  				}
  				else if(jframe.getGame().getSecondPlayer().getLeader().getName().equals((buttons[i][j]).getText())){
  					s+="Leader"+"\n";
  				}
  				else 
  					s+="Not Leader"+"\n";
  				s+="Effects: "+"\n";
  				for(int m=0 ;m<c1.getAppliedEffects().size();m++){
  					Effect eff=c1.getAppliedEffects().get(m);
  					s+="Name: "+eff.getName() +"\n" +"Duration: "+eff.getDuration()+"\n";
  				}
  				JOptionPane.showMessageDialog(this,s,"Champion Information",JOptionPane.INFORMATION_MESSAGE);  
  				return;
  			  }
  			  }
  			  
  		  }
  		  }
		
		}
        		
	}
	public void fillBoard(){
		for(int x=0 ;x<5;x++){
			for(int y=0;y<5;y++){
				buttons[x][y].setText("");
			}
		}
  	  for(int i=4;i>=0 ;i--	){
  		  for(int j=0;j<5;j++){
  			 if(jframe.getGame().getBoard()[i][j] instanceof Champion){
  				 if(jframe.getGame().getBoard()[i][j] == jframe.getGame().getCurrentChampion()){
				    	 buttons[i][j].setBackground(Color.MAGENTA);
				    	 buttons[i][j].setText( ((Champion)jframe.getGame().getBoard()[i][j]).getName() );
				     }
  				 else if(jframe.getGame().getFirstPlayer().getTeam().contains(jframe.getGame().getBoard()[i][j] )){
  				     
  				        buttons[i][j].setBackground(Color.CYAN);
  				        buttons[i][j].setText(((Champion)jframe.getGame().getBoard()[i][j]).getName() );
  				        }
  				else if(jframe.getGame().getSecondPlayer().getTeam().contains(jframe.getGame().getBoard()[i][j] )) {
  					 
  					   buttons[i][j].setBackground(Color.YELLOW);
  					   buttons[i][j].setText( ((Champion)jframe.getGame().getBoard()[i][j]).getName() );
  				}
  			 }
  			 else if(jframe.getGame().getBoard()[i][j] instanceof Cover){
  				 buttons[i][j].setText("HP " + ((Cover)jframe.getGame().getBoard()[i][j]).getCurrentHP());
  				 buttons[i][j].setBackground(Color.RED);
  			 }
  			 else buttons[i][j].setBackground(Color.GREEN);
  				 
  		  }
  		  this.revalidate();
      	  this.repaint();
  		  }
  	 
  	this.revalidate();
	  this.repaint();
    }
	
	
	

}
