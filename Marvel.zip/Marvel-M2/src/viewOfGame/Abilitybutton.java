package viewOfGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.world.Direction;
import exceptions.AbilityUseException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;

public class Abilitybutton extends JPanel implements ActionListener {
	private View jframe;
	private GamePhase g;
	private Board b;
	private JButton ability1;
	private JButton ability2;
	private JButton ability3;
	private JButton leaderability;
	private JLabel leaderabilitytype;
	private JComboBox choosedirection;
	private JLabel xplace;
	private JLabel yplace;
	private JTextField x;
	private JTextField y;
	
	
	
	public Abilitybutton(GamePhase g,View jframe , Board b){
		this.jframe=jframe;
		this.g=g;
		this.b=b;
		this.setLayout(null);
		this.setBackground(Color.LIGHT_GRAY);
		
		ability1=new JButton();
		ability1.setBounds(30, 50, 150, 40);
		ability1.addActionListener(this);
		this.add(ability1);
		
		ability2=new JButton();
		ability2.setBounds(200, 50, 150, 40);
		ability2.addActionListener(this);
		this.add(ability2);
		
		ability3=new JButton();
		ability3.setBounds(370, 50, 150, 40);
		ability3.addActionListener(this);
		this.add(ability3);
		
		abilitiesbuttons();
		
		leaderabilitytype=new JLabel("Leader Ability: ");
		leaderabilitytype.setBounds(40, 150, 200, 40);
		Font f6=new Font("",Font.BOLD,18);
		leaderabilitytype.setFont(f6);
		this.add(leaderabilitytype);
		
		leaderability=new JButton("USE IT");
		leaderability.setBounds(200, 150, 150, 40);
		leaderability.addActionListener(this);
		this.add(leaderability);
		
		String [] d={"UP" ,"DOWN","RIGHT" ,"LEFT"};
		choosedirection=new JComboBox(d);
		choosedirection.setBounds(230, 100, 100, 40);
		this.add(choosedirection);
		
		xplace=new JLabel("Place x if singletarget");
		xplace.setBounds(40, 200, 200, 30);
		Font f7=new Font("",Font.BOLD,18);
		xplace.setFont(f7);
		this.add(xplace);
		
		x=new JTextField();
		x.setBounds(250, 200, 70, 30);
		this.add(x);
		
		yplace=new JLabel("Place y if singletarget");
		yplace.setBounds(40, 250, 200, 30);
		Font f8=new Font("",Font.BOLD,18);
		yplace.setFont(f8);
		this.add(yplace);
		
		y=new JTextField();
		y.setBounds(250, 250, 70, 30);
		this.add(y);
		
		
		
		

		
		this.revalidate();
	  	this.repaint();
		
	}
	
	public void abilitiesbuttons(){
		ability1.setText(jframe.getGame().getCurrentChampion().getAbilities().get(0).getName());
		
		ability2.setText(jframe.getGame().getCurrentChampion().getAbilities().get(1).getName());
		
		ability3.setText(jframe.getGame().getCurrentChampion().getAbilities().get(2).getName());
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
    if(e.getSource()==ability1){
   	 ArrayList<Ability> a=jframe.getGame().getCurrentChampion().getAbilities();
   	  for(int i=0 ;i<jframe.getGame().getCurrentChampion().getAbilities().size();i++){
   		  if(a.get(i).getName()==ability1.getText()){
   			  if(a.get(i).getCastArea()==AreaOfEffect.SELFTARGET || a.get(i).getCastArea()==AreaOfEffect.SURROUND ||
   					  a.get(i).getCastArea()==AreaOfEffect.TEAMTARGET ){
					
						try {
							jframe.getGame().castAbility(a.get(i));
//							JTextArea area=new JTextArea(jframe.CurrentChampion());
//							g.setText(area);
							
						} catch (NotEnoughResourcesException
								| AbilityUseException
								| CloneNotSupportedException e1) {
							JOptionPane.showMessageDialog(this,e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
							
						}
						
					
   			  }
   			  else if(a.get(i).getCastArea()==AreaOfEffect.DIRECTIONAL){
   				  int n=choosedirection.getSelectedIndex();
   				  if(n==0){
   					 
							try {
								jframe.getGame().castAbility(a.get(i),Direction.DOWN);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
						
   				  }
   				  if(n==1){
   					  
							try {
								jframe.getGame().castAbility(a.get(i),Direction.UP);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
						
   				  }
   				  if(n==2){
   					  
							try {
								jframe.getGame().castAbility(a.get(i),Direction.RIGHT);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
						
   				  }
   				  if(n==3){
   					  
							try {
								jframe.getGame().castAbility(a.get(i),Direction.LEFT);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
						
   				  }
   				 
   			  }
   			  else if(a.get(i).getCastArea()==AreaOfEffect.SINGLETARGET){
   				  if(x.getText().equals("")||y.getText().equals("")){
   					  JOptionPane.showMessageDialog(this, "Please enter x and y coordinates", "ERORR",JOptionPane.ERROR_MESSAGE );
   				  } else
					try {
						jframe.getGame().castAbility(a.get(i), Integer.parseInt(x.getText()), Integer.parseInt(y.getText()));
//						JTextArea area=new JTextArea(jframe.CurrentChampion());
//						g.setText(area);
						
					} catch (NumberFormatException
							| NotEnoughResourcesException | AbilityUseException
							| InvalidTargetException
							| CloneNotSupportedException e1) {
						JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
						
					}
   				  
   			  }
   			
   		  }
   		 
   	  }
    }
    if(e.getSource()==ability2){
      	 ArrayList<Ability> a=jframe.getGame().getCurrentChampion().getAbilities();
      	  for(int i=0 ;i<jframe.getGame().getCurrentChampion().getAbilities().size();i++){
      		  if(a.get(i).getName()==ability2.getText()){
      			  if(a.get(i).getCastArea()==AreaOfEffect.SELFTARGET || a.get(i).getCastArea()==AreaOfEffect.SURROUND ||
      					  a.get(i).getCastArea()==AreaOfEffect.TEAMTARGET ){
   					
   						try {
							jframe.getGame().castAbility(a.get(i));
//							JTextArea area=new JTextArea(jframe.CurrentChampion());
//							g.setText(area);
						} catch (NotEnoughResourcesException
								| AbilityUseException
								| CloneNotSupportedException e1) {
							JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
						
						}
   						break;
   					
      			  }
      			  else if(a.get(i).getCastArea()==AreaOfEffect.DIRECTIONAL){
      				  int n=choosedirection.getSelectedIndex();
      				  if(n==0){
      					  
   							try {
								jframe.getGame().castAbility(a.get(i),Direction.DOWN);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
   						
      				  }
      				  if(n==1){
      					 
   							try {
								jframe.getGame().castAbility(a.get(i),Direction.UP);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
   						
      				  }
      				  if(n==2){
      					  
   							try {
								jframe.getGame().castAbility(a.get(i),Direction.RIGHT);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
   						
      				  }
      				  if(n==3){
      					  
   						try {
							jframe.getGame().castAbility(a.get(i),Direction.LEFT);
//							JTextArea area=new JTextArea(jframe.CurrentChampion());
//							g.setText(area);
						} catch (NotEnoughResourcesException
								| AbilityUseException
								| CloneNotSupportedException e1) {
							JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
							
						}
   						
      				 
      			  }
      			  }
      			  else if(a.get(i).getCastArea()==AreaOfEffect.SINGLETARGET){

       				  if(x.getText().equals("")||y.getText().equals("")){
       					  JOptionPane.showMessageDialog(this, "Please enter x and y coordinates", "ERORR",JOptionPane.ERROR_MESSAGE );
       				  } else
    					try {
    						jframe.getGame().castAbility(a.get(i), Integer.parseInt(x.getText()), Integer.parseInt(y.getText()));
//    						JTextArea area=new JTextArea(jframe.CurrentChampion());
//							g.setText(area);
    					} catch (NumberFormatException
    							| NotEnoughResourcesException | AbilityUseException
    							| InvalidTargetException
    							| CloneNotSupportedException e1) {
    						JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
    						
    					}
       				  
       			  
      				  
      				  
      			  }
      			
      		  }
      		 
      	  }
       }
      	  
    if(e.getSource()==ability3){
      	 ArrayList<Ability> a=jframe.getGame().getCurrentChampion().getAbilities();
      	  for(int i=0 ;i<jframe.getGame().getCurrentChampion().getAbilities().size();i++){
      		  if(a.get(i).getName()==ability3.getText()){
      			  if(a.get(i).getCastArea()==AreaOfEffect.SELFTARGET || a.get(i).getCastArea()==AreaOfEffect.SURROUND ||
      					  a.get(i).getCastArea()==AreaOfEffect.TEAMTARGET ){
   					
   						try {
							jframe.getGame().castAbility(a.get(i));
//							JTextArea area=new JTextArea(jframe.CurrentChampion());
//							g.setText(area);
						} catch (NotEnoughResourcesException
								| AbilityUseException
								| CloneNotSupportedException e1) {
							JOptionPane.showMessageDialog(this,e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
							
						}
   						break;
   					
      			  }
      			  else if(a.get(i).getCastArea()==AreaOfEffect.DIRECTIONAL){
      				  int n=choosedirection.getSelectedIndex();
      				  if(n==0){
      					  
   							try {
								jframe.getGame().castAbility(a.get(i),Direction.DOWN);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
   						
      				  }
      				  if(n==1){
      					 
   							try {
								jframe.getGame().castAbility(a.get(i),Direction.UP);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
   						
      				  }
      				  if(n==2){
      					  
   							try {
								jframe.getGame().castAbility(a.get(i),Direction.RIGHT);
//								JTextArea area=new JTextArea(jframe.CurrentChampion());
//								g.setText(area);
							} catch (NotEnoughResourcesException
									| AbilityUseException
									| CloneNotSupportedException e1) {
								JOptionPane.showMessageDialog(this,e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
								
							}
   						
      				  }
      				  if(n==3){
      					  
   						try {
							jframe.getGame().castAbility(a.get(i),Direction.LEFT);
//							JTextArea area=new JTextArea(jframe.CurrentChampion());
//							g.setText(area);
						} catch (NotEnoughResourcesException
								| AbilityUseException
								| CloneNotSupportedException e1) {
							JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
							
						}
   						
      				 
      			  }
      			  }
      			  else if(a.get(i).getCastArea()==AreaOfEffect.SINGLETARGET){

       				  if(x.getText().equals("")||y.getText().equals("")){
       					  JOptionPane.showMessageDialog(this, "Please enter x and y coordinates", "ERORR",JOptionPane.ERROR_MESSAGE );
       				  } else
    					try {
    						jframe.getGame().castAbility(a.get(i), Integer.parseInt(x.getText()), Integer.parseInt(y.getText()));
//    						JTextArea area=new JTextArea(jframe.CurrentChampion());
//							g.setText(area);
    					} catch (NumberFormatException
    							| NotEnoughResourcesException | AbilityUseException
    							| InvalidTargetException
    							| CloneNotSupportedException e1) {
    						JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
    					
    					}
       				  
       			  
      				  
      				  
      			  }
      			
      		  }
      		 
      	  }
       }
      	  
   	  
   	 if(e.getSource()==leaderability){

			try {
				jframe.getGame().useLeaderAbility();
//				JTextArea area=new JTextArea(jframe.CurrentChampion());
//				g.setText(area);
			} catch (LeaderNotCurrentException
					| LeaderAbilityAlreadyUsedException e1) {
				JOptionPane.showMessageDialog(this, e1.getMessage(),"UNAWLLOED ACTION", JOptionPane.ERROR_MESSAGE);
				
			}
		
     }
   	 b.fillBoard();
     
		
	}  

}
