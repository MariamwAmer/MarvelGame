package viewOfGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;

import model.world.Direction;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.NotEnoughResourcesException;

public class Attackdirection extends JPanel implements ActionListener {
	private View jframe;
	private Board b;
	private GamePhase g;
	private JLabel attack;
	private JButton attackup;
	private JButton attackdown;
	private JButton attackright;
	private JButton attackleft;
	
	public Attackdirection(View jframe , GamePhase g  , Board b){
		this.jframe=jframe;
		this.g=g;
		
		this.b = b;
		this.setBackground(Color.LIGHT_GRAY);
		this.setLayout(null);
		
		attack=new JLabel("Attack Buttons");
		attack.setBounds(190, 50, 250, 40);
		Font f3=new Font(" ",Font.PLAIN,20);
		attack.setFont(f3);
		this.add(attack);
		
		attackdown=new JButton("UP");
		attackdown.setBounds(200, 100, 90, 40);
		attackdown.addActionListener(this);
		this.add(attackdown);
		
        attackup=new JButton("DOWN");
        attackup.setBounds(200, 200, 90, 40);
        attackup.addActionListener(this);
		this.add(attackup);
		
		attackleft=new JButton("LEFT");
		attackleft.setBounds(100, 150, 90, 40);
		attackleft.addActionListener(this);
		this.add(attackleft);
		
		attackright=new JButton("RIGHT");
		attackright.setBounds(300, 150, 90, 40);
		attackright.addActionListener(this);
		this.add(attackright);
		
		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==attackup){
	    	  
				try {
					jframe.getGame().attack(Direction.UP);
					
				} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e1) {
					JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
				}
			    
	    	  
	      }
	      if(e.getSource()==attackdown){
	    	 
				try {
					jframe.getGame().attack(Direction.DOWN);
				} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e1) {
					JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
				}
			
	    	  
	      }
	      if(e.getSource()==attackright){
	    	  
				try {
					jframe.getGame().attack(Direction.RIGHT);
				} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e1) {
					JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
				}
			
	    	  
	      }
	      if(e.getSource()==attackleft){
	    	  
				try {
					jframe.getGame().attack(Direction.LEFT);
				} catch (NotEnoughResourcesException
						| ChampionDisarmedException | InvalidTargetException e1) {
					
					JOptionPane.showMessageDialog(this, e1.getMessage(), "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
				}
		 
	    	  
	      }
	      
		b.fillBoard();
	}
	
	
	

}
