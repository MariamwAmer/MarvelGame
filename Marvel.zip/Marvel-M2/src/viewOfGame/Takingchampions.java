package viewOfGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.AbstractButton;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JRadioButton;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.text.JTextComponent;

public class Takingchampions extends JPanel implements ActionListener{
	private View jframe;
	private JLabel text1;
	private JLabel text2;
	private JTextArea display;
	public JComboBox box1;
	public JComboBox box2;
	public JComboBox box3;
	public JComboBox box4;
	public JComboBox box5;
	public JComboBox box6;
	public ButtonGroup group1;
	public ButtonGroup group2;
	public JRadioButton dot1;
	public JRadioButton dot2;
	public JRadioButton dot3;
	public JRadioButton dot4;
	public JRadioButton dot5;
	public JRadioButton dot6;
	private JButton b;
	private JScrollPane scroll;
	public static int leader1;
	public static int leader2;
	
	public Takingchampions(View jframe){
		this.jframe=jframe;
		this.setLayout(null);
		this.setBackground(Color.RED);
		
		text1=new JLabel("Please Choose first player champions");
		text1.setBounds(80, 50, 600, 30);
		Font f1=new Font(" ",Font.BOLD,25);
		text1.setFont(f1);
		this.add(text1);
		
		box1=new JComboBox(jframe.NamesforCombobox());
	    box1.setBounds(120, 90,200, 40);
	    box1.setBackground(Color.LIGHT_GRAY);
	    Font f9=new Font(" ",Font.PLAIN,20);
		box1.setFont(f9);
		box1.addActionListener(this);
	    this.add(box1);
	    
	    dot1=new JRadioButton("Select if leader");
	    dot1.setBounds(120, 150, 200, 30);
	    dot1.setSelected(true);
	    dot1.addActionListener(this);
	    this.add(dot1);
	    
	    box2=new JComboBox(jframe.NamesforCombobox());
	    box2.setBounds(120, 250, 200, 40);
	    box2.setBackground(Color.LIGHT_GRAY);
	    Font f8=new Font(" ",Font.PLAIN,20);
		box2.setFont(f8);
		box2.addActionListener(this);
	    this.add(box2);
	    
	    dot2=new JRadioButton("Select if leader");
	    dot2.setBounds(120, 310, 200, 30);
	    dot2.addActionListener(this);
	    this.add(dot2);
	    
	    box3=new JComboBox(jframe.NamesforCombobox());
	    box3.setBounds(120, 410, 200, 40);
	    box3.setBackground(Color.LIGHT_GRAY);
	    Font f7=new Font(" ",Font.PLAIN,20);
		box3.setFont(f7);
		box3.addActionListener(this);
	    this.add(box3);
	    
	    dot3=new JRadioButton("Select if leader");
	    dot3.setBounds(120, 470, 200, 30);
	    dot3.addActionListener(this);
	    this.add(dot3);
		
	    text2=new JLabel("Please Choose second player champions");
		text2.setBounds(1400, 50, 600, 30);
		Font f2=new Font(" ",Font.BOLD,25);
		text2.setFont(f2);
		this.add(text2);
		
	    box4=new JComboBox(jframe.NamesforCombobox());
	    box4.setBounds(1440, 90, 200, 40);
	    box4.setBackground(Color.LIGHT_GRAY);
	    Font f6=new Font(" ",Font.PLAIN,20);
		box4.setFont(f6);
		box4.addActionListener(this);
	    this.add(box4);
	    
	    dot4=new JRadioButton("Select if leader");
	    dot4.setBounds(1440, 150, 200, 30);
	   dot4.setSelected(true);
	    dot4.addActionListener(this);
	    this.add(dot4);
		
	    box5=new JComboBox(jframe.NamesforCombobox());
	    box5.setBounds(1440, 250, 200, 40);
	    box5.setBackground(Color.LIGHT_GRAY);
	    Font f5=new Font(" ",Font.PLAIN,20);
		box5.setFont(f5);
		box5.addActionListener(this);
	    this.add(box5);
	    
	    dot5=new JRadioButton("Select if leader");
	    dot5.setBounds(1440, 310, 200, 30);
	    dot5.addActionListener(this);
	    this.add(dot5);
		
	    box6=new JComboBox(jframe.NamesforCombobox());
	    box6.setBounds(1440, 410, 200, 40);
	    box6.setBackground(Color.LIGHT_GRAY);
	    Font f4=new Font(" ",Font.PLAIN,20);
		box6.setFont(f4);
		box6.addActionListener(this);
	    this.add(box6);
	    
	    dot6=new JRadioButton("Select if leader");
	    dot6.setBounds(1440, 470, 200, 30);
	    dot6.addActionListener(this);
	    this.add(dot6);
		
		b=new JButton("Start");
		b.setBounds(900,800, 90, 40);
		b.setBackground(Color.BLUE);
		Font f3=new Font(" ",Font.BOLD,20);
		b.setFont(f3);
		b.addActionListener(this);
		this.add(b);
		
		group1=new ButtonGroup();
		group1.add(dot1);
		group1.add(dot2);
		group1.add(dot3);
		
		group2=new ButtonGroup();
		group2.add(dot4);
		group2.add(dot5);
		group2.add(dot6);
		
		display=new JTextArea();
		Font font=new Font(" ",Font.BOLD,25);
	    scroll=new JScrollPane(display);
		scroll.setBounds(700,100, 500, 400);
		display.setFont(font);
		display.setBackground(Color.LIGHT_GRAY);
		display.setEditable(false);
	    this.add(scroll);
	    
		this.revalidate();
		this.repaint();		
		
	}

	@Override
	public void actionPerformed(ActionEvent e) {
		if(e.getSource()==box1){
			display.setText(jframe.championInformation(box1.getSelectedIndex()));
			
			return;
		}
		else if(e.getSource()==box2){
			display.setText(jframe.championInformation(box2.getSelectedIndex()));
			return;
		}
		else if(e.getSource()==box3){
			display.setText(jframe.championInformation(box3.getSelectedIndex()));		
			return;
		}
		else if(e.getSource()==box4){
			display.setText(jframe.championInformation(box4.getSelectedIndex()));		
			return;
		}
		else if(e.getSource()==box5){
			display.setText(jframe.championInformation(box5.getSelectedIndex()));		
			return;
		}
		else if(e.getSource()==box6){
			display.setText(jframe.championInformation(box6.getSelectedIndex()));		
			return;
		}
		else if(e.getSource()==b){
			ArrayList <Integer> a=new ArrayList<Integer>();
			a.add(box1.getSelectedIndex());
			if(a.contains(box2.getSelectedIndex())){
					JOptionPane.showMessageDialog(this,"Please choose different champions", "Error", JOptionPane.ERROR_MESSAGE);
					return;
			}
			else
				a.add(box2.getSelectedIndex());
			if(a.contains(box3.getSelectedIndex())){
				JOptionPane.showMessageDialog(this,"Please choose different champions", "Error", JOptionPane.ERROR_MESSAGE);
				return;
		}
		else
			a.add(box3.getSelectedIndex());
			if(a.contains(box4.getSelectedIndex())){
				JOptionPane.showMessageDialog(this,"Please choose different champions", "Error", JOptionPane.ERROR_MESSAGE);
				return;
		}
		else
			a.add(box4.getSelectedIndex());
			if(a.contains(box5.getSelectedIndex())){
				JOptionPane.showMessageDialog(this,"Please choose different champions", "Error", JOptionPane.ERROR_MESSAGE);
				return;
		}
		else
			a.add(box5.getSelectedIndex());
			if(a.contains(box6.getSelectedIndex())){
				JOptionPane.showMessageDialog(this,"Please choose different champions", "Error", JOptionPane.ERROR_MESSAGE);
				return;
		}
		else
			a.add(box6.getSelectedIndex());
		
		}
		
				
		if(e.getSource()==dot1){
			 leader1=box1.getSelectedIndex();
			 
			 return;
		}
		if(e.getSource()==dot2){
			 leader1=box2.getSelectedIndex();
			 
			 return;
		}
		if(e.getSource()==dot3){
			 leader1=box3.getSelectedIndex();
			 
			 return;
		}
		if(e.getSource()==dot4){
			 leader2=box4.getSelectedIndex();
			 return;
		}
		if(e.getSource()==dot5){
			 leader2=box5.getSelectedIndex();
			 return;
		}
		if(e.getSource()==dot6){
			 leader2=box6.getSelectedIndex();
			 return;
		}
		
		jframe.changePanel2(box1.getSelectedIndex(),box2.getSelectedIndex(),box3.getSelectedIndex(),box4.getSelectedIndex(),box5.getSelectedIndex(),box6.getSelectedIndex());
		
			

		
			
		
	}
	
	
	

}
