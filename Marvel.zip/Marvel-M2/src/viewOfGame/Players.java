package viewOfGame;


import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.IOException;


import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class Players extends JPanel implements ActionListener{
	private View jframe;
	private JLabel display1;
	private JTextField text1;
	private JLabel display2;
	private JTextField text2;
	private JButton b;
	
	
	public Players(View jframe){
		this.jframe=jframe;
		this.setBackground(Color.RED);
		this.setLayout(null);
		
		display1=new JLabel("Please enter first player name");
		display1.setBounds(750, 50, 400, 30);
		Font f1=new Font(" ",Font.BOLD,25);
		display1.setFont(f1);
		this.add(display1);

		text1=new JTextField();
		text1.setBounds(750, 100, 150, 30);
		text1.setBackground(Color.WHITE);
		this.add(text1);
		
		display2=new JLabel("Please enter second player name");
		display2.setBounds(750, 200, 400, 30);
		Font f2=new Font(" ",Font.BOLD,25);
		display2.setFont(f2);
		this.add(display2);
		
		text2=new JTextField();
		text2.setBounds(750, 250, 150, 30);
		text2.setBackground(Color.WHITE);
		this.add(text2);
		
		b=new JButton("Next");
		b.setBounds(900,550,90,40);
		Font f3=new Font(" ",Font.BOLD,20);
		b.setFont(f3);
		b.setBackground(Color.BLUE);
		b.addActionListener(this);
		this.add(b);
		
		
	   this.revalidate();
	   this.repaint();
		
	}
	


	

	@Override
	public void actionPerformed(ActionEvent e){
		 if(e.getSource()==b){
			 if(text1.getText().equals("")){
				 JOptionPane.showMessageDialog(this, "Please enter player 1 name","Error",JOptionPane.ERROR_MESSAGE);
			 }
			 else
			 if(text2.getText().equals("")){
				 JOptionPane.showMessageDialog(this, "Please enter player 2 name","Error",JOptionPane.ERROR_MESSAGE);
			 }
			 else
			 if(!(text1.getText().equals("") && text2.getText().equals("")) ){
				 try {
					jframe.changePanel1( text1.getText(), text2.getText());
				} catch (IOException e1) {
					e1.printStackTrace();
				}
			 }
		 }
		
		
	}
}


