package viewOfGame;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JTextArea;

import model.world.Direction;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;

public class Movedirection extends JPanel implements ActionListener{
	private View jframe;
	private Board b;
	private GamePhase g;
	private JLabel move;
	private JButton moveup;
	private JButton movedown;
	private JButton moveright;
	private JButton moveleft;
	public Movedirection(View jframe , GamePhase g, Board b){
		this.jframe=jframe;
		this.g=g;
		this.b = b;
		this.setBackground(Color.LIGHT_GRAY);
		this.setLayout(null);
		
		move=new JLabel("Move Buttons");
		move.setBounds(230, 50, 250, 40);
		Font f3=new Font(" ",Font.PLAIN,20);
	    move.setFont(f3);
		this.add(move);
		
		movedown=new JButton("UP");
		movedown.setBounds(240, 100, 90, 40);
		movedown.addActionListener(this);
		this.add(movedown);
		
		moveup=new JButton("DOWN");
		moveup.setBounds(240, 200, 90, 40);
		moveup.addActionListener(this);
		this.add(moveup);
		
		moveleft=new JButton("LEFT");
		moveleft.setBounds(140, 150, 90, 40);
		moveleft.addActionListener(this);
		this.add(moveleft);
		
		moveright=new JButton("RIGHT");
		moveright.setBounds(340, 150, 90, 40);
		moveright.addActionListener(this);
		this.add(moveright);
		
		
		
		
		
	}
	@Override
	public void actionPerformed(ActionEvent e) {
		
		if(e.getSource()==moveup){
			try {
				jframe.getGame().move(Direction.UP);
				
			} catch (NotEnoughResourcesException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage()  , "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
			} catch (UnallowedMovementException e1) {
				JOptionPane.showMessageDialog(this,e1.getMessage()  , "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
			}
		}
      if(e.getSource()==movedown){
    	  try {
			jframe.getGame().move(Direction.DOWN);
					} catch (NotEnoughResourcesException e1) {
			JOptionPane.showMessageDialog(this,e1.getMessage()  , "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
		} catch (UnallowedMovementException e1) {
			JOptionPane.showMessageDialog(this,e1.getMessage() , "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
		}
      }
      if(e.getSource()==moveright){
    	  try {
			jframe.getGame().move(Direction.RIGHT);
		} catch (NotEnoughResourcesException e1) {
			JOptionPane.showMessageDialog(this,e1.getMessage() , "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
		} catch (UnallowedMovementException e1) {
			JOptionPane.showMessageDialog(this,e1.getMessage()  , "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
		}
      }
      if(e.getSource()==moveleft){
    	  try {
			jframe.getGame().move(Direction.LEFT);
		} catch (NotEnoughResourcesException e1) {
			JOptionPane.showMessageDialog(this,e1.getMessage()  , "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
					} catch (UnallowedMovementException e1) {
			JOptionPane.showMessageDialog(this,e1.getMessage() , "UNALLOWED ACTION", JOptionPane.ERROR_MESSAGE);
		}
      }
      b.fillBoard();
      jframe.revalidate();
      jframe.repaint();
	}

}
