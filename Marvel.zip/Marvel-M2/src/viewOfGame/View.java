package viewOfGame;

import java.awt.Color;
import java.awt.Component;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.io.IOException;
import java.util.ArrayList;

import javax.swing.ImageIcon;
import javax.swing.JFrame;
import javax.swing.JLabel;

import model.abilities.Ability;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.effects.Effect;
import model.world.Champion;
import engine.Game;
import engine.Player;

public class View extends JFrame implements MouseListener {
	private Game game;
	private ImageIcon image;
	private JLabel label;
	private Players p;
	private String player1name;
	private String player2name;
	private Takingchampions t;
	private GamePhase g;

	public View() {
       
        image = new ImageIcon("MarvelOpening.jpg");
		label = new JLabel(image);
		label.addMouseListener(this);
		this.getContentPane().add(label);

		

		this.setBounds(0,0, 1010, 600);
		this.setTitle("Marvel Game");
		this.setVisible(true);
		this.setDefaultCloseOperation(EXIT_ON_CLOSE);

		this.revalidate();
		this.repaint();

	}

	@Override
	public void mouseClicked(MouseEvent e) {
		if (e.getSource() == label) {
			this.remove(label);
			this.setBounds(0, 50, 2000, 700);
			p = new Players(this);
			this.getContentPane().add(p);
			this.revalidate();
			this.repaint();

		}
	}

	@Override
	public void mouseEntered(MouseEvent arg0) {

	}

	@Override
	public void mouseExited(MouseEvent arg0) {

	}

	@Override
	public void mousePressed(MouseEvent e) {
		if (e.getSource() == label) {
			this.remove(label);
			this.setBounds(0, 0, 2000, 1000);
			p = new Players(this);
			this.getContentPane().add(p);
			this.revalidate();
			this.repaint();

		}
	}

	@Override
	public void mouseReleased(MouseEvent arg0) {

	}

	public void changePanel1(String name1, String name2) throws IOException {
		this.getContentPane().remove(p);
		player1name = name1;
		player2name = name2;
		Game.loadAbilities("Abilities.csv");
		Game.loadChampions("Champions.csv");
		t = new Takingchampions(this);
		this.add(t);
		this.setBounds(0, 0, 2000, 1000);
		this.revalidate();
		this.repaint();
		
		
		
		

	}

	public void changePanel2(int c1, int c2, int c3, int c4, int c5, int c6){
		this.remove(t);
		
		if(t.dot1.isSelected())
			t.leader1 = t.box1.getSelectedIndex();
		else if(t.dot2.isSelected())
			t.leader1 = t.box2.getSelectedIndex();
		else if(t.dot3.isSelected())
			t.leader1 = t.box3.getSelectedIndex();

		if(t.dot4.isSelected())
			t.leader2 = t.box4.getSelectedIndex();
		else if(t.dot5.isSelected())
			t.leader2 = t.box5.getSelectedIndex();
		else if(t.dot6.isSelected())
			t.leader2 = t.box6.getSelectedIndex();

		
		
		
		
		
		int l1=t.leader1;
		int l2=t.leader2;
		
		Player p1 = new Player(player1name);
		p1.getTeam().add(Game.getAvailableChampions().get(c1));
		p1.getTeam().add(Game.getAvailableChampions().get(c2));
		p1.getTeam().add(Game.getAvailableChampions().get(c3));
		p1.setLeader(Game.getAvailableChampions().get(l1));

		Player p2 = new Player(player2name);
		p2.getTeam().add(Game.getAvailableChampions().get(c4));
		p2.getTeam().add(Game.getAvailableChampions().get(c5));
		p2.getTeam().add(Game.getAvailableChampions().get(c6));
		p2.setLeader(Game.getAvailableChampions().get(l2));

		game=new Game(p1,p2);
		g=new GamePhase(this);
		this.getContentPane().add(g);
		this.revalidate();
		this.repaint();

	}

	public String[] NamesforCombobox() {
		ArrayList<Champion> champions = new ArrayList<Champion>();
		champions = Game.getAvailableChampions();
		String[] championsnames = new String[champions.size()];
		for (int i = 0; i < champions.size(); i++) {
			championsnames[i] = (champions.get(i).getName());
		}
		return championsnames;

	}

	public Game getGame() {
		return game;
	}

	public String getPlayer1name() {
		return player1name;
	}

	public String getPlayer2name() {
		return player2name;
	}

	public String championInformation(int i) {
		ArrayList<Champion> c = Game.getAvailableChampions();
		Champion c1 = c.get(i);
		String s = "Name of Champion: " + c1.getName() + "\n"
				+ "Current Healthpoints: " + c1.getCurrentHP() + "\n"
				+ "Mana: " + c1.getMana() + "\n" + "Current Action Points: "
				+ c1.getCurrentActionPoints() + "\n" + "Attack Damage: "
				+ c1.getAttackDamage() + "\n" + "Attack Range: "
				+ c1.getAttackRange() + "\n" + "Speed: " + c1.getSpeed() + "\n"
				+ "Abilities:" + "\n" ;
		
		ArrayList <Ability> a=c1.getAbilities();

		for(int x=0 ; x<a.size();x++){
			s+= "*Name: " + a.get(x).getName() +"\n"+"BaseCoolDown: "+a.get(x).getBaseCooldown()+"\n"+"CurrentCoolDown: "+a.get(x).getCurrentCooldown()+"\n"+
		"Mana Cost: "+a.get(x).getManaCost()+"\n"+"Required Action Points: "+a.get(x).getRequiredActionPoints()+"\n"+"Cast Area: "+a.get(x).getCastArea()+"\n"+
		"Cast Range: "+a.get(x).getCastRange()+"\n";
			if(a.get(x) instanceof CrowdControlAbility){
				CrowdControlAbility ability=(CrowdControlAbility)a.get(x);
				s+="Crowd Control Ability" +"\n"
				
						
						
						;
			}
			else if(a.get(x) instanceof HealingAbility){
				HealingAbility ability=(HealingAbility)a.get(x);
				s+="Healing Ability" +"\n" +"Healing Amount: "+ ability.getHealAmount()+"\n";
			}
			else if(a.get(x) instanceof DamagingAbility){
				DamagingAbility ability=(DamagingAbility)a.get(x);
				s+="Damaging Ability" +"\n" +"Damage Amount: "+ ability.getDamageAmount()+"\n";
			}
		}
		
		
		
		
		
		return s;

	}
	
	
	public String CurrentChampion(){
		String info="";
		Champion c=getGame().getCurrentChampion();
		
		info="Details of current champion: " +"\n"+  "Name of Champion: " + c.getName() + "\n"
				+ "Current Healthpoints: " + c.getCurrentHP() + "\n"
				+ "Mana: " + c.getMana() + "\n" + "Current Action Points: "
				+ c.getCurrentActionPoints() + "\n" + "Attack Damage: "
				+ c.getAttackDamage() + "\n" + "Attack Range: "
				+ c.getAttackRange() +"\n" + "Speed: " + c.getSpeed() + "\n"
				+ "Abilities:" + "\n"+"\n" ;
		ArrayList <Ability> a=c.getAbilities();
		for(int i=0 ; i<a.size();i++){
			info+= "*Name: " + a.get(i).getName() +"\n"+"BaseCoolDown: "+a.get(i).getBaseCooldown()+"\n"+"CurrentCoolDown: "+a.get(i).getCurrentCooldown()+"\n"+
		"Mana Cost: "+a.get(i).getManaCost()+"\n"+"Required Action Points: "+a.get(i).getRequiredActionPoints()+"\n"+"Cast Area: "+a.get(i).getCastArea()+"\n"+
		"Cast Range: "+a.get(i).getCastRange()+"\n";
			if(a.get(i) instanceof CrowdControlAbility){
				CrowdControlAbility ability=(CrowdControlAbility)a.get(i);
				info+="Crowd Control Ability" +"\n" +"Effect: "+ ability.getEffect().getName()+"\n" +"Effect Type: "+ ability.getEffect().getType() +"\n";
			}
			else if(a.get(i) instanceof HealingAbility){
				HealingAbility ability=(HealingAbility)a.get(i);
				info+="Healing Ability" +"\n" +"Healing Amount: "+ ability.getHealAmount()+"\n";
			}
			else if(a.get(i) instanceof DamagingAbility){
				DamagingAbility ability=(DamagingAbility)a.get(i);
				info+="Damaging Ability" +"\n" +"Damage Amount: "+ ability.getDamageAmount()+"\n";
			}
		}
		info+="Effects :"+"\n";
		for(int m=0 ;m<c.getAppliedEffects().size();m++){
				Effect eff=c.getAppliedEffects().get(m);
				info+="Name: "+eff.getName() +"\n" +"Duration: "+eff.getDuration()+"\n";
			}
		
		return info;
	}
	

	public static void main(String[] args) {
		new View();

	}

}
