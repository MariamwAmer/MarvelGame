package viewOfGame;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.text.JTextComponent;

import exceptions.AbilityUseException;
import exceptions.ChampionDisarmedException;
import exceptions.InvalidTargetException;
import exceptions.LeaderAbilityAlreadyUsedException;
import exceptions.LeaderNotCurrentException;
import exceptions.NotEnoughResourcesException;
import exceptions.UnallowedMovementException;
import model.abilities.Ability;
import model.abilities.AreaOfEffect;
import model.abilities.CrowdControlAbility;
import model.abilities.DamagingAbility;
import model.abilities.HealingAbility;
import model.world.Champion;
import model.world.Direction;

public class GamePhase extends JPanel implements ActionListener {
	private View jframe;
	private Board b;
	private JLabel name1;
	private JLabel name2;
	private Attackdirection attack;
	private JTextArea text;
	private JScrollPane scroll;
	private Movedirection move;
	private Abilitybutton button;
	private JButton endturn;
	private JTextArea orderofchampions;
	
	

	
	public GamePhase(View jframe){
		this.jframe=jframe;
		this.setLayout(null);
		this.setBackground(Color.LIGHT_GRAY);
		
		b=new Board(this,jframe);
		b.fillBoard();
		this.add(b);
		
		name1=new JLabel("Player 1 Name: " + jframe.getPlayer1name());
		name1.setBounds(60, 30, 250, 40);
		Font f1=new Font(" ",Font.PLAIN,20);
	    name1.setFont(f1);
		this.add(name1);
		
		name2=new JLabel("Player 2 Name: " + jframe.getPlayer2name());
		name2.setBounds(1600, 30, 250, 40);
		Font f2=new Font(" ",Font.PLAIN,20);
	    name2.setFont(f2);
		this.add(name2);
		
		move=new Movedirection(jframe,this , b);
		move.setBounds(1400, 700, 500, 400);
		this.add(move);
		
		attack=new Attackdirection(jframe,this , b);
		attack.setBounds(0, 700, 400, 400);
		this.add(attack);
		
		endturn=new JButton("END TURN");
		endturn.setBounds(925, 900, 100, 40);
		endturn.addActionListener(this);
		this.add(endturn);
		
		text=new JTextArea(jframe.CurrentChampion());
		Font f5=new Font(" ",Font.PLAIN,13);
		text.setFont(f5);
		text.setEditable(false);
		scroll=new JScrollPane(text);
		scroll.setBounds(1450, 90 , 400, 600);
		this.add(scroll);
		
		
		button=new Abilitybutton(this,jframe,b);
		button.setBounds(0,70, 800, 300);
		this.add(button);
		
		orderofchampions=new JTextArea(jframe.getGame().turnofchampions());
		orderofchampions.setBounds(90, 400, 200, 200);
		orderofchampions.setBackground(Color.YELLOW);
		orderofchampions.setEditable(false);
		this.add(orderofchampions);
		

  	   this.revalidate();
  	   this.repaint();
			}
	



	public JTextArea getText() {
		return text;
	}




	public void setText(JTextArea text) {
		this.text = text;
	}




	@Override
	public void actionPerformed(ActionEvent e) {
      if(e.getSource()==endturn){	
    	  jframe.getGame().endTurn();
    	  text.setText(jframe.CurrentChampion());
          b.fillBoard();
          button.abilitiesbuttons();
          orderofchampions.setText(jframe.getGame().turnofchampions());	
       this.revalidate();
       this.repaint();
       orderofchampions.revalidate();
       orderofchampions.repaint();
       
          
      }
      
      if(jframe.getGame().checkGameOver()!=null){
    	  JOptionPane.showMessageDialog(this, "Game Over the WINNER is " + jframe.getGame().checkGameOver().getName(), "WINNER!", JOptionPane.INFORMATION_MESSAGE);
    	  jframe.dispose();
      }
    
      
      
      
	}
	
	
	
	
	

}
